from django.apps import AppConfig


class NetflixappConfig(AppConfig):
    name = 'netflixapp'
